// @ts-nocheck
// Inspired by react-hot-toast library
import { useState, useEffect } from "react";

const TOAST_LIMIT = 5;
const TOAST_REMOVE_DELAY = 3000; // 3 seconds auto-dismiss
const TOAST_STAGGER_MS = 700; // spacing between toasts when many arrive

const actionTypes = {
  ADD_TOAST: "ADD_TOAST",
  UPDATE_TOAST: "UPDATE_TOAST",
  DISMISS_TOAST: "DISMISS_TOAST",
  REMOVE_TOAST: "REMOVE_TOAST",
};

let count = 0;

function genId() {
  count = (count + 1) % Number.MAX_VALUE;
  return count.toString();
}

const toastTimeouts = new Map();

// pending add timers to stagger toast appearance
const pendingAddTimers = new Map();
const pendingProps = new Map();
let lastDispatchTime = 0;

const addToRemoveQueue = (toastId) => {
  if (toastTimeouts.has(toastId)) {
    return;
  }

  const timeout = setTimeout(() => {
    toastTimeouts.delete(toastId);
    dispatch({
      type: actionTypes.REMOVE_TOAST,
      toastId,
    });
  }, TOAST_REMOVE_DELAY);

  toastTimeouts.set(toastId, timeout);
};

const _clearFromRemoveQueue = (toastId) => {
  const timeout = toastTimeouts.get(toastId);``
  if (timeout) {
    clearTimeout(timeout);
    toastTimeouts.delete(toastId);
  }
};

export const reducer = (state, action) => {
  switch (action.type) {
    case actionTypes.ADD_TOAST:
      return {
        ...state,
        toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT),
      };

    case actionTypes.UPDATE_TOAST:
      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === action.toast.id ? { ...t, ...action.toast } : t
        ),
      };

    case actionTypes.DISMISS_TOAST: {
      const { toastId } = action;

      // ! Side effects ! - This could be extracted into a dismissToast() action,
      // but I'll keep it here for simplicity
      if (toastId) {
        addToRemoveQueue(toastId);
      } else {
        state.toasts.forEach((toast) => {
          addToRemoveQueue(toast.id);
        });
      }

      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === toastId || toastId === undefined
            ? {
                ...t,
                open: false,
              }
            : t
        ),
      };
    }
    case actionTypes.REMOVE_TOAST:
      if (action.toastId === undefined) {
        return {
          ...state,
          toasts: [],
        };
      }
      return {
        ...state,
        toasts: state.toasts.filter((t) => t.id !== action.toastId),
      };
  }
};

const listeners = [];

let memoryState = { toasts: [] };

function dispatch(action) {
  memoryState = reducer(memoryState, action);
  listeners.forEach((listener) => {
    listener(memoryState);
  });
}

function toast({ ...props }) {
  const id = genId();

  const update = (newProps) => {
    // if pending, merge into pendingProps
    if (pendingProps.has(id)) {
      pendingProps.set(id, { ...pendingProps.get(id), ...newProps });
    } else {
      dispatch({ type: actionTypes.UPDATE_TOAST, toast: { ...newProps, id } });
    }
  };

  const dismiss = () => {
    // if pending add, cancel it
    const t = pendingAddTimers.get(id);
    if (t) {
      clearTimeout(t);
      pendingAddTimers.delete(id);
      pendingProps.delete(id);
      return;
    }
    dispatch({ type: actionTypes.DISMISS_TOAST, toastId: id });
  };

  // schedule add with staggering
  try {
    const now = Date.now();
    const sinceLast = Math.max(0, now - lastDispatchTime);
    const delay = pendingAddTimers.size > 0 ? (pendingAddTimers.size * TOAST_STAGGER_MS) : Math.max(0, TOAST_STAGGER_MS - sinceLast);
    pendingProps.set(id, props);
    const timer = setTimeout(() => {
      pendingAddTimers.delete(id);
      const p = pendingProps.get(id) || {};
      pendingProps.delete(id);
      dispatch({
        type: actionTypes.ADD_TOAST,
        toast: {
          ...p,
          id,
          open: true,
          onOpenChange: (open) => {
            if (!open) dismiss();
          },
        },
      });
      lastDispatchTime = Date.now();
      // schedule auto remove
      addToRemoveQueue(id);
    }, delay);
    pendingAddTimers.set(id, timer);
  } catch {
    // fallback to immediate
    dispatch({
      type: actionTypes.ADD_TOAST,
      toast: { ...props, id, open: true, onOpenChange: (open) => { if (!open) dismiss(); } },
    });
    addToRemoveQueue(id);
    lastDispatchTime = Date.now();
  }

  return { id, dismiss, update };
}

function useToast() {
  const [state, setState] = useState(memoryState);

  useEffect(() => {
    listeners.push(setState);
    return () => {
      const index = listeners.indexOf(setState);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  }, [state]);

  return {
    ...state,
    toast,
    dismiss: (toastId) => dispatch({ type: actionTypes.DISMISS_TOAST, toastId }),
  };
}

export { useToast, toast }; 
export function clearToasts() {
  // remove all toasts
  dispatch({ type: actionTypes.REMOVE_TOAST, toastId: undefined });
}