import React from "react";
import { useDemoRunner } from "@/hooks/useDemoRunner";
import { clearToasts } from "@/components/ui/use-toast";
import { Play, StopCircle } from "lucide-react";

export default function StartDemoButton({ onEvent }) {
  const { running, timeLeft, start, stop } = useDemoRunner({ duration: 300000, onEvent });

  return (
    <div className="flex items-center gap-2">
      {!running ? (
        <button
          onClick={() => {
            try { clearToasts(); } catch {}
            start();
          }}
          className="inline-flex items-center gap-2 px-2 py-1 rounded bg-primary text-white text-sm"
          title="Start demo data (5 minutes)"
        >
          <Play className="w-4 h-4" />
          <span className="hidden sm:inline">Start Demo</span>
        </button>
      ) : (
        <button
          onClick={() => {
            try { clearToasts(); } catch {}
            stop();
          }}
          className="inline-flex items-center gap-2 px-2 py-1 rounded bg-destructive text-white text-sm"
          title="Stop demo"
        >
          <StopCircle className="w-4 h-4" />
          <span className="hidden sm:inline">Stop Demo</span>
          <span className="ml-2 text-xs font-mono">{Math.ceil(timeLeft / 1000)}s</span>
        </button>
      )}
    </div>
  );
}
